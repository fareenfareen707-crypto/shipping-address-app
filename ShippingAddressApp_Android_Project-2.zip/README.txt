SHIPPING ADDRESS ANDROID APP

Included:
- Separate FROM and TO address fields (name, 10-digit mobile, full address, 6-digit PIN)
- Save and view address history locally on the device
- Generate and share a PDF shipping label
- Print shipping details using Android Print
- Share details to WhatsApp (or Android share sheet if WhatsApp is unavailable)

BUILD APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing Android Studio project.
3. Allow Gradle sync and install any requested Android SDK (compileSdk 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location, usually app/build/outputs/apk/debug/app-debug.apk.

NOTES:
- This package is source project files, not a precompiled APK.
- Saved address history stays on the phone in app-private storage.
- PDF files are saved in the app's external-files/ShippingLabels folder.
- For production release, configure app signing and test printing/PDF sharing on the target Android version.
