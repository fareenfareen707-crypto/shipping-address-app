package com.example.shippingaddress;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.print.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText[] from = new EditText[4], to = new EditText[4];
    LinearLayout root;
    String[] labels = {"Full name", "Mobile number", "Full address", "PIN code"};
    android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("shipping", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scroll.setFillViewport(true); scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("SHIPPING ADDRESS"); title.setTextSize(24); title.setTextColor(Color.rgb(18,78,67));
        title.setTypeface(null, 1); root.addView(title);
        addSection("FROM ADDRESS", from);
        addSection("TO ADDRESS", to);

        addButton("Save address history", v -> saveHistory());
        addButton("View saved address history", v -> showHistory());
        addButton("Generate PDF", v -> createPdf());
        addButton("Print shipping label", v -> printLabel());
        addButton("Share on WhatsApp", v -> shareWhatsApp());
        addButton("Clear form", v -> clearForm());
    }

    int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density); }
    void addSection(String name, EditText[] fields) {
        TextView h = new TextView(this); h.setText(name); h.setTextSize(18);
        h.setTypeface(null,1); h.setTextColor(Color.rgb(23,107,91));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2); hp.topMargin=dp(22); hp.bottomMargin=dp(8);
        root.addView(h,hp);
        for (int i=0;i<4;i++) {
            EditText e = new EditText(this); e.setSingleLine(i!=2);
            e.setTextSize(16); e.setPadding(dp(12),dp(10),dp(12),dp(10));
            e.setHint(name.startsWith("FROM") ? "Sender " + labels[i] : "Receiver " + labels[i]);
            if (i==2) { e.setSingleLine(false); e.setMinLines(2); }
            if (i==1) e.setInputType(3);
            if (i==3) e.setInputType(2);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(8);
            root.addView(e,p); fields[i]=e;
        }
    }
    void addButton(String text, View.OnClickListener listener) {
        Button b = new Button(this); b.setText(text);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.topMargin=dp(7);
        root.addView(b,p); b.setOnClickListener(listener);
    }
    String val(EditText e) { return e.getText().toString().trim(); }
    String details() {
        return "FROM\n"+val(from[0])+"\n"+val(from[1])+"\n"+val(from[2])+"\nPIN: "+val(from[3])+
               "\n\nTO\n"+val(to[0])+"\n"+val(to[1])+"\n"+val(to[2])+"\nPIN: "+val(to[3]);
    }
    boolean valid() {
        for(EditText e:from) if(val(e).isEmpty()){e.setError("Required");e.requestFocus();return false;}
        for(EditText e:to) if(val(e).isEmpty()){e.setError("Required");e.requestFocus();return false;}
        if(!val(from[1]).matches("[0-9]{10}") || !val(to[1]).matches("[0-9]{10}")) {
            Toast.makeText(this,"Enter 10-digit mobile numbers",Toast.LENGTH_LONG).show(); return false;
        }
        if(!val(from[3]).matches("[0-9]{6}") || !val(to[3]).matches("[0-9]{6}")) {
            Toast.makeText(this,"Enter 6-digit PIN codes",Toast.LENGTH_LONG).show(); return false;
        }
        return true;
    }
    void saveHistory() {
        if(!valid()) return;
        try {
            JSONArray a = new JSONArray(prefs.getString("history","[]"));
            JSONObject o = new JSONObject();
            o.put("date", new java.text.SimpleDateFormat("dd-MM-yyyy HH:mm",Locale.getDefault()).format(new Date()));
            o.put("text",details()); a.put(o);
            prefs.edit().putString("history",a.toString()).apply();
            Toast.makeText(this,"Address saved on this device",Toast.LENGTH_SHORT).show();
        } catch(Exception ex){ Toast.makeText(this,"Could not save",Toast.LENGTH_SHORT).show(); }
    }
    void showHistory() {
        try {
            JSONArray a = new JSONArray(prefs.getString("history","[]"));
            if(a.length()==0){Toast.makeText(this,"No saved addresses",Toast.LENGTH_SHORT).show();return;}
            StringBuilder s=new StringBuilder();
            for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);s.append(o.optString("date")).append("\n").append(o.optString("text")).append("\n\n----------------\n\n");}
            new AlertDialog.Builder(this).setTitle("Saved address history").setMessage(s.toString())
                .setPositiveButton("Close",null).setNeutralButton("Share latest",(d,w)->shareText(a.optJSONObject(a.length()-1).optString("text"))).show();
        } catch(Exception e){}
    }
    void shareWhatsApp() {
        if(!valid()) return;
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,details());
        i.setPackage("com.whatsapp");
        try{startActivity(i);}catch(Exception e){shareText(details());}
    }
    void shareText(String text) {
        Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,text);
        startActivity(Intent.createChooser(i,"Share shipping details"));
    }
    void clearForm(){ for(EditText e:from)e.setText(""); for(EditText e:to)e.setText(""); }
    void createPdf() {
        if(!valid()) return;
        PdfDocument doc=new PdfDocument();
        PdfDocument.PageInfo info=new PdfDocument.PageInfo.Builder(595,842,1).create();
        PdfDocument.Page page=doc.startPage(info); Canvas c=page.getCanvas();
        Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(Color.BLACK); p.setTextSize(18); p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));
        c.drawText("SHIPPING LABEL",40,55,p);
        p.setTextSize(13); p.setTypeface(Typeface.DEFAULT);
        String[] lines=details().split("\n"); int y=100;
        for(String line:lines){ if(y>790)break; c.drawText(line,40,y,p); y+=25; }
        doc.finishPage(page);
        try {
            File dir=new File(getExternalFilesDir(null),"ShippingLabels"); if(!dir.exists())dir.mkdirs();
            File f=new File(dir,"shipping_label_"+System.currentTimeMillis()+".pdf");
            FileOutputStream out=new FileOutputStream(f); doc.writeTo(out); out.close(); doc.close();
            Toast.makeText(this,"PDF saved: "+f.getAbsolutePath(),Toast.LENGTH_LONG).show();
            Intent share=new Intent(Intent.ACTION_SEND); share.setType("application/pdf");
            android.net.Uri uri=androidx.core.content.FileProvider.getUriForFile(this,getPackageName()+".provider",f);
            share.putExtra(Intent.EXTRA_STREAM,uri); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            // PDF remains saved locally even if no compatible share app is installed.
            startActivity(Intent.createChooser(share,"Share PDF"));
        } catch(Exception e){doc.close(); Toast.makeText(this,"PDF creation failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    void printLabel() {
        if(!valid()) return;
        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
        pm.print("Shipping label",new PrintDocumentAdapter(){
            @Override public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){
                if(cs.isCanceled()){cb.onLayoutCancelled();return;}
                PrintDocumentInfo info=new PrintDocumentInfo.Builder("shipping_label.txt").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).build();
                cb.onLayoutFinished(info,true);
            }
            @Override public void onWrite(PageRange[] ranges,ParcelFileDescriptor dest,CancellationSignal cs,WriteResultCallback cb){
                try {
                    String text=details().replace("\n","\r\n");
                    FileOutputStream out=new FileOutputStream(dest.getFileDescriptor());
                    out.write(text.getBytes("UTF-8")); out.close(); cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                }catch(Exception e){cb.onWriteFailed(e.getMessage());}
            }
        },null);
    }
}
